El archivo races.py esta compuesto de 3 funciones
con las cuales se realiza procesamiento de texto
y aritmetico para obtener una respuesta a quien es el ganador del Grand Prix.

calculate_points: Calcula los puntos que recibe un piloto en base a X sistema de puntuacion
determine_champions: Procesa los puntajes de cada piloto en cada carrera y cada sistema de puntuacion
para retornar los ganadores de un Grand Prix.
process_input: Recibe la informacion en el formato y reglas propuestos por el problema y lo convierte en
numeros simples con los cuales pueden trabajar las operaciones anteriores

Para probar el correcto funcionamiento podemos ejecutar "Unit test 1.py" y otros archivos de pruebas