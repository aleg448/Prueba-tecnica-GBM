El archivo palindromo.py contiene la funcion es_palindromo
Al llamarse esta funcion se puede retornar "Es palindromo" o "No es palindromo"
Indicando si la linea de texto cumple la condicion de "Palindromo"

Para probar el correcto funcionamiento podemos ejecutar "Unit test 1.py" y otros archivos de pruebas
al ejecutarse estos comparan una linea de texto que ya sabemos si es "Palindroma" y nos indica que la prueba fue exitosa
Si el output de la prueba es diferente al esperado, salta el error AssertionError