El archivo jumping.py tiene como objetivo calcular la menor cantidad de pasos necesarios para 
llegar de 0 a X siguiendo una serie de reglas y contine dos funciones: 
minimum_jumps: recibe (X) y retorna la cantidad minima de saltos necesario para llegar a el
process_test_cases: recibe una lista de datos (input_data), los alimenta a minimum_jumps uno por uno
Y retorna otra lista (results) con los saltos calculados para cada item.

Para probar el correcto funcionamiento podemos ejecutar "Unit test 1.py" y otros archivos de pruebas